"""
我们已经知道了将N个整数按从小到大排序的冒泡排序法。本题要求将此方法用于字符串序列，并对任意给定的K（<N），输出扫描完第K遍后的中间结果序列。

输入格式：
输入在第1行中给出N和K（1≤K<N≤100），此后N行，每行包含一个长度不超过10的、仅由小写英文字母组成的非空字符串。

输出格式：
输出冒泡排序法扫描完第K遍后的中间结果序列，每行包含一个字符串。
"""
N, K = map(int, input().split())
A = []
for i in range(N):
    A.append(input())


# 冒泡排序（从小到大排序的冒泡排序法）
def Bubble_sort(n, k, a):
    for i in range(k):  # k遍
        for j in range(n - 1 - i):  # 一次循环找到一个最大值
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
    return a


A = Bubble_sort(N, K, A)
for i in range(N):  # 逐行输出
    print(A[i])
