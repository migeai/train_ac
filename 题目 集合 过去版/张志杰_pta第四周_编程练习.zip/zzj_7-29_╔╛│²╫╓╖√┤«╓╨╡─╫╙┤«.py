"""
输入2个字符串S1和S2，要求删除字符串S1中出现的所有子串S2，即结果字符串中不能包含S2。

输入格式：
输入在2行中分别给出不超过80个字符长度的、以回车结束的2个非空字符串，对应S1和S2。

输出格式：
在一行中输出删除字符串S1中出现的所有子串S2后的结果字符串。
"""
S1 = input()
S2 = input()


def f(s1, s2):  # 删除字符串中的子串
    result1 = ""
    result2 = s1
    flag = 0
    i = 0
    while i < len(s1):
        if s1[i:i + len(s2)] == s2:
            i += len(s2)
            flag = 1
        else:
            result1 += s1[i]
            i += 1
    if flag == 1:
        f(result1, s2)
    else:
        print(result2)
        # return result2  # 返回上一次的字符串失效


f(S1, S2)
# result=f(S1, S2)
# print(result)
