# 将初始状态存储为一个3x3矩阵
start_state = [[1, 2, 3], [8, 0, 4], [7, 6, 5]]
# 目标状态
goal_state = [[2, 8, 3], [1, 0, 4], [7, 6, 5]]
# 定义了移动方向和移动状态的值
move_direct_value = {'up': (-1, 0), 'down': (1, 0), 'left': (0, -1), 'right': (0, 1)}


# 估计函数h(x) // 启发函数
def h(now_state, goal):
    dis = 0
    for i in range(3):
        for j in range(3):
            if now_state[i][j] != goal[i][j]:  # 最简单的判断 位置上的数不同 计数
                dis += 1
    return dis


# 定义找到目标数字0的位置
def find_zero(matrix, item):
    for i, row in enumerate(matrix):
        for j, cell in enumerate(row):  # 返回tuple类型的index,value
            if cell == item:
                return i, j


# 深度优先搜索算法实现，返回最短路径
def dfs(start, goal):
    visited = set()  # close表 不重复
    stack = [[start]]  # open表 0初始化
    while stack:  # 不为空
        path = stack.pop()  # 弹出
        current_state = path[-1]
        if current_state == goal:
            return path
        visited.add(tuple(map(tuple, current_state)))
        for direct, (x, y) in move_direct_value():
            row, col = find_zero(current_state, 0)
            new_row, new_col = row + x, col + y
            if 0 <= new_col < 3 and 0 <= new_row < 3:  # 没有超出(0, 2)
                new_state = [x[:] for x in current_state]
                new_state[row][col], new_state[new_row][new_col] = new_state[new_row][new_col], 0  # 交换
                if tuple(map(tuple, new_state)) not in visited:
                    new_path = path + [new_state]
                    stack.append(new_path)


# 广度优先搜索算法实现，返回最短路径
def bfs(start, goal):
    visited = set()  # close表 不重复
    queue = [[start]]  # open表 0初始化
    while queue:
        path = queue.pop(0)
        current_state = path[-1]
        if current_state == goal:
            return path
        visited.add(tuple(map(tuple, current_state)))
        for direction, (dx, dy) in move_direct_value.items():
            row, col = find_zero(current_state, 0)
            new_row, new_col = row + dx, col + dy
            if 0 <= new_row < 3 and 0 <= new_col < 3:
                new_state = [x[:] for x in current_state]
                new_state[row][col], new_state[new_row][new_col] = new_state[new_row][new_col], 0  # 交换
                if tuple(map(tuple, new_state)) not in visited:
                    new_path = path + [new_state]
                    queue.append(new_path)


# 打印结果
def print_result(result):
    for i in range(3):
        for j in range(3):
            print(result[i][j], end=' ')
        print()


# 实现
print("初始状态：")
print_result(start_state)
bfs_path = bfs(start_state, goal_state)
# dfs_path = dfs(initial_state, goal_state)

# print("深度优先搜索得到的最短路径长度为：", len(dfs_path) - 1)
# print("深度优先搜索得到的最短路径为：")
# for state in dfs_path:
#    print_result(state)
#    print()

print("广度优先搜索得到的最短路径长度为：", len(bfs_path) - 1)
print("广度优先搜索得到的最短路径为：")
i = 0
for state in bfs_path:
    print("**%d**" % i)
    print_result(state)
    i += 1