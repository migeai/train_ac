"""
给你一个长度为 n 的整数数组nums和 一个目标值target。请你从 nums 中选出三个整数，使它们的和与target最接近。

返回这三个数的和。

假定每组输入只存在恰好一个解。
"""
class Solution:
    def threeSumClosest(self, nums: List[int], target: int) -> int:
        res = 100000  # 记录结果
        dif = 100000 # 记录差值
        nums.sort()  # 排序 从大到小
        n = len(nums)  # 数组长度
        for i in range(n):
            if i > 0 and nums[i] == nums[i-1]:  # 避免重复计算
                continue
            l, r = i + 1, n - 1  # 左右指针
            while l < r:
                s = nums[i] + nums[l] + nums[r]  # 记录当前的值
                if s == target:  # 结果最小
                    return target
                if dif > abs(s-target):  # 找到更接近的
                    dif = abs(s-target)
                    res = s
                if s > target:  # 偏大
                    r -= 1
                else:  # 偏小
                    l += 1
        return res
