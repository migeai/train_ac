"""
给定一个仅包含数字2-9的字符串，返回所有它能表示的字母组合。答案可以按 任意顺序 返回。

给出数字到字母的映射如下（与电话按键相同）。注意 1 不对应任何字母。

"""

class Solution:
    def letterCombinations(self, digits: str) -> List[str]:
        res = []  # 记录结果
        n = len(digits)  # 记录长度
        phone_dict = {
            '2': ['a', 'b', 'c'],
            '3': ['d', 'e', 'f'],
            '4': ['g', 'h', 'i'],
            '5': ['j', 'k', 'l'],
            '6': ['m', 'n', 'o'],
            '7': ['p', 'q', 'r', 's'],
            '8': ['t', 'u', 'v'],
            '9': ['w', 'x', 'y', 'z']
        }  # 建立数字与字母的映射关系表
        if not digits:  # 考虑到空表 0 <= digits.length <= 4
            return res
        def dfs(cur_str, next_cur, dict_map):  # dfs算法
            if not next_cur:  # 叶子节点
                res.append(cur_str)
            else:
                for letter in dict_map[next_cur[0]]:
                    dfs(cur_str+letter, next_cur[1:], dict_map)
        dfs('', digits, phone_dict)  # 刚开始组合为空 陆续添加字符
        return res