"""
本题要求编写程序，顺序读入浮点数1、整数、字符、浮点数2，再按照字符、整数、浮点数1、浮点数2的顺序输出。

输入格式：
输入在一行中顺序给出浮点数1、整数、字符、浮点数2，其间以1个空格分隔。

输出格式：
在一行中按照字符、整数、浮点数1、浮点数2的顺序输出，其中浮点数保留小数点后2位。
"""
#  输入
float_1, int_num, char_num, float_2 = input().split()

# 输出
print(char_num, int_num, format(float(float_1), '.2f'), format(float(float_2), '.2f'))