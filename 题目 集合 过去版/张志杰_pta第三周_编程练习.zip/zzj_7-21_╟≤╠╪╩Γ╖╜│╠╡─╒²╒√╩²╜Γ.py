"""
本题要求对任意给定的正整数N，求方程X**2+Y**2=N的全部正整数解。

输入格式：
输入在一行中给出正整数N（≤10000）。

输出格式：
输出方程X**2 +Y**2=N的全部正整数解，其中X≤Y。
  每组解占1行，两数字间以空格分隔，按X的递增顺序输出。如果没有解，则输出No Solution。
"""

# 数据输入
N = int(input())
flag = 0  # 记录有无解

# 数据处理
# 考虑正整数解且N<= 10000
c = int(N ** 0.5)
for x in range(1, c):
    for y in range(1, c+1):  # 考虑1 + 4 = 5这种
        if x ** 2 + y ** 2 == N and x <= y:
            print('%d %d' % (x, y))
            flag = 1
if flag == 0:
    print("No Solution")