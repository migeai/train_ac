"""
求解f(x) = a3*x**3+a2*x**2+a1*x+a0
"""
# 数据输入
a3, a2, a1, a0 = map(float, input().split())
a, b = map(float, input().split())


# 定义f(x)函数
def f(x):
    return a3 * x ** 3 + a2 * x ** 2 + a1 * x + a0


# 数据处理
def dichotomy(a5, b1):  # 二分法
    if b1 - a5 < 0.001:
        print((a5 + b1) / 2)
    elif f(a5) * f(b1) < 0:
        if f((a5 + b1) / 2) == 0:
            print((a5 + b1) / 2)
        else:
            if f((a5 + b1) / 2) * f(a5) > 0:
                a5 = (a5 + b1) / 2
                dichotomy(a5, b1)
            elif f((a5 + b1) / 2) * f(b1) > 0:
                b1 = (a5 + b1) / 2
                dichotomy(a5, b1)
    elif f(a5) == 0:  # 考虑到a, b可能是根
        print(a5)
    elif f(b1) == 0:
        print(b1)

# 数据输出
# x1 = dichotomy(a, b) 因为return返回语句返回是None为解决,就在函数体内直接输出结果
# print(x1)
