"""
根据下面关系式，求圆周率的值，直到最后一项的值小于给定阈值。

pi / 2 = 1 + n!/3 * 5 * 7 *(2n+1)

输入格式：
输入在一行中给出小于1的阈值。

输出格式：
在一行中输出满足阈值条件的近似圆周率，输出到小数点后6位。
"""
# 数据输入
threshold_value = float(input())

# 数据输出,数据输出
sum_1 = 1
pi_2 = 0
sum_2 = sum_3 = 1  # 记录阶乘和(2n+1)的值
n = 1
if threshold_value < 1:  # 输入是否满足条件
    while threshold_value < sum_1:  # 是否超出阈值
        if n > 1:
            sum_2 = sum_2 * (n - 1)
            sum_3 = sum_3 * (2 * n - 1)
        else:
            sum_2 = sum_3 = 1
        sum_1 = sum_2 / sum_3  # 每项2的值
        pi_2 += sum_1  # 求和
        n += 1  # 项数的增加
    print('{:.6f}'.format(pi_2 * 2))
