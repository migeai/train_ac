"""
给定不超过6的正整数A，考虑从A开始的连续4个数字。请输出所有由它们组成的无重复数字的3位数。

输入格式：
输入在一行中给出A。

输出格式：
输出满足条件的的3位数，要求从小到大，每行6个整数。整数间以空格分隔，但行末不能有多余空格。
"""
# 数据输入
A = int(input())
B = A + 4
n = 0

#  数据处理
for i in range(A, B):
    for j in range(A, B):
        if i == j:
            continue
        for k in range(A, B):
            if i == k or j == k:
                continue
            n += 1
            if n < 6:
                print(str(i * 100 + j * 10 + k) + ' ', end='')
            else:
                n = 0
                print(str(i * 100 + j * 10 + k) + '\n', end='')
