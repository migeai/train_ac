"""
给你一个由 n 个整数组成的数组nums ，和一个目标值 target 。
请你找出并返回满足下述全部条件且不重复的四元组[nums[a], nums[b], nums[c], nums[d]]
（若两个四元组元素一一对应，则认为两个四元组重复）：

0 <= a, b, c, d< n
a、b、c 和 d 互不相同
nums[a] + nums[b] + nums[c] + nums[d] == target
你可以按 任意顺序 返回答案 。
"""


class Solution:
    def fourSum(self, nums: List[int], target: int) -> List[List[int]]:
        result = []  # 接受结果
        nums.sort()  # 排序后方便遍历
        n = len(nums)

        for i in range(0, n - 3):  # 四个数，遍历到倒数第四个
            if i > 0 and nums[i] == nums[i - 1]:  # 避免结果重复
                continue

            for j in range(i + 1, n - 2):  # 在i的后面不超过倒数第3个
                if j > i + 1 and nums[j] == nums[j - 1]:
                    continue

                left = j + 1
                right = n - 1  # 左右指针
                while left < right:
                    s = nums[i] + nums[j] + nums[left] + nums[right]
                    if s == target:  # 满足条件
                        result.append([nums[i], nums[j], nums[left], nums[right]])
                        while left < right and nums[left] == nums[left + 1]:
                            left += 1
                        while left < right and nums[right] == nums[right - 1]:
                            right -= 1
                        left += 1
                        right -= 1
                    elif s < target:  # 偏小
                        left += 1
                    else:  # 偏大
                        right -= 1
        return result
