"""
24. 两两交换链表中的节点
给你一个链表，两两交换其中相邻的节点，并返回交换后链表的头节点。你必须在不修改节点内部的值的情况下完成本题（即，只能进行节点交换）。
"""

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        if not head or not head.next:
            # 当head.next 和 head 调换位置是会发生错误，链表为空时先处理head.next会AttributeError: 'NoneType'
            # object has no attribute 'next'
            return head
        one = head
        two = one.next
        three = two.next

        # 交换
        two.next = one
        one.next = self.swapPairs(three)

        return two