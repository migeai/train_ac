"""
给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
"""


# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def removeNthFromEnd(self, head: Optional[ListNode], n: int) -> Optional[ListNode]:
        # 创建新的指针指向链表
        a = ListNode(0)
        a.next = head

        # 双指针
        one = a
        two = a

        # 先是遍历n
        for i in range(n):
            one = one.next

        # 接着对于one还剩下len(head) - n + 1
        while one.next:
            one = one.next
            two = two.next
        # 对于two的下一个删除
        two.next = two.next.next

        return a.next
