"""
数字 n 代表生成括号的对数，请你设计一个函数，用于能够生成所有可能的并且 有效的 括号组合。
"""

class Solution:
    def generateParenthesis(self, n: int) -> List[str]:
        res = []
        if n == 0:
            return []
        def dfs(s, left, right):
            if left > n or right > left: # 减枝 右半边括号要小等于左半边 括号最对为n
                return
            if len(s) == 2 * n:
                res.append(s)
                return
            dfs(s+'(', left+1, right)  # 逐一添加
            dfs(s+')', left, right+1)

        dfs('', 0, 0)
        return res