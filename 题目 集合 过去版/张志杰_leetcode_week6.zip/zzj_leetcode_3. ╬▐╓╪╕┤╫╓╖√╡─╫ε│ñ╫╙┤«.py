"""
给定一个字符串 s ，请你找出其中不含有重复字符的 最长子串 的长度。
"""


# 审题可以发现这是一个滑动窗口的问题
#


class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:  # 返回类型int 传入一个字符串
        left = right = 0  # 开始的位置
        lens = 0  # 记录不含有重复字符的 最长子串 的长度

        # if len(s) == 0:  # 空字符串
        #     return 0
        # if s.count(s[0]) == len(s):  # 全部字符相同
        #     return 1
        # if len(set(s)) == len(s):  # 全部字符不同
        #     return len(s) 这些都是特殊情况的加上后运行的速度会更快
        while right < len(s):  # 扫描整个字符串
            if s[right] not in s[left:right]:  # 如果新的字符不重复
                right += 1  # 右指针👉右
                lens = max(lens, len(s[left:right]))  # 更新长度
            else:
                left += 1  # 左指针👈左
        return lens
