"""
给你一个字符串 s，找到 s 中最长的回文子串。

如果字符串的反序与原始字符串相同，则该字符串称为回文字符串。
1 <= s.length <= 1000  # 大小不用判断
s 仅由数字和英文字母组成
"""


# 中心扩展算法
# 由于回文字串是左右对称的，所以循环遍历中心，左右扩展


class Solution:
    def longestPalindrome(self, s: str) -> str:
        start = end = 0  # 起始的位置
        for i in range(len(s)):  # 开始遍历n
            left1, right1 = self.expandRoundCenter(s, i, i)  # 回文字符串是奇数
            left2, right2 = self.expandRoundCenter(s, i, i + 1)  # 回文字符串是偶数
            if right1 - left1 > end - start:
                start, end = left1, right1
            if right2 - left2 > end - start:
                start, end = left2, right2  # 更新最大回文字符串
        return s[start:end+1]  # python的切片是左闭右开

    def expandRoundCenter(self, s, left, right):  # 中心扩展实现
        while left >= 0 and right < len(s) and s[left] == s[right]:  # 左右的端点不出界
            left -= 1
            right += 1
        return left + 1, right - 1  # 因为最后的的s[left] != s[right] 所以返回值要小一对




