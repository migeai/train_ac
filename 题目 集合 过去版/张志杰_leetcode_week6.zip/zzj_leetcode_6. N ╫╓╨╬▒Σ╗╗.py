"""
将一个给定字符串 s 根据给定的行数 numRows ，以从上往下、从左到右进行Z 字形排列。

比如输入字符串为 "PAYPALISHIRING"行数为 3 时，排列如下：

"""


# 考虑到使用数组会浪费一部分空间，所以直接构造结果


class Solution:
    def convert(self, s: str, numRows: int) -> str:
        n, r = len(s), numRows  # 记录字符串的长度 和 Z的行数
        if r == 1 or r > n:  # 特殊情况 没有循环体的时候
            return s
        t = 2 * r - 2  # t = r + r - 2 循环体 Z的前部分
        ans = []  # 记录结果
        for i in range(r):  # 遍历每一行
            for j in range(0, n - i, t):  # 每一个循环体 n-i是因为s[j+i]会超出范围
                ans.append(s[j + i])  # 循环体的首字符
                if 0 < i < r - 1 and j + t - i:  # 可能存在的第二个字符 注意列表下标的范围
                    ans.append(s[j + t - i])  # 从每个循环体的末尾开始依次减去i
        return ''.join(ans)

